BRAIN LAB INSTALLABLE WEB APP

This is a PWA package, not an APK.
For installation on Android, the files must be hosted on an HTTPS web address.

After hosting:
1. Open the web address in Chrome.
2. Let Brain Lab load once.
3. Chrome menu -> Install app (or Add to Home screen).
4. Launch Brain Lab from the new icon.
5. It can then work offline after caching.

Includes 60 questions per puzzle, 14 puzzle categories, and 25-second timers.
